Vigil compact native ONNX package

The external compact-model.onnx and compact-model.onnx.json pair is required.
Keep it with the executable and ONNX Runtime libraries.
Run: vigil-compact --require-model --model compact-model.onnx --metadata compact-model.onnx.json --runtime-lib <packaged-runtime-library> --format json <skill-package>
