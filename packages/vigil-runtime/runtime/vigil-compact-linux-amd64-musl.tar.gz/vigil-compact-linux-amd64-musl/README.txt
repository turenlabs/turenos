Vigil compact classifier runtime for Linux x86_64 musl.

Built from the pinned Vigil source and model with Alpine Linux 3.24 ONNX Runtime 1.24.4.
The accompanying shared-library dependency closure is loaded only from this package directory.
